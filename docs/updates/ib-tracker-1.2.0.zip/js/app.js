/* app.js — bootstrap */
(function () {
  "use strict";
  const App = window.App;

  App.applyTheme();
  App.backfillSubjectLevels();
  App.recordGradeSnapshot(false);
  App.subscribe(() => App.render());
  window.addEventListener("hashchange", () => App.renderNow());

  if (!location.hash) location.replace("#/dashboard");

  // Settle the licence before the first paint, so the UI never briefly offers
  // edits it is about to refuse. It's one signature check — well under a
  // millisecond — and load() swallows its own errors, but the .catch stays as
  // a belt-and-braces guarantee: if this promise never settled, bootOK() below
  // would never fire and the shell would roll back a perfectly good update.
  App.license.load().catch(() => {}).then(() => {
    App.renderNow();

    // Tell the desktop shell this build booted cleanly (it rolls a bad update
    // back otherwise), then look for a newer version in the background.
    if (window.ibUpdater && window.ibUpdater.bootOK) window.ibUpdater.bootOK();
    App.updates.boot();
  });
})();
