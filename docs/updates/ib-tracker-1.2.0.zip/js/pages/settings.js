/* pages/settings.js — subjects, study hours, appearance, and the data hub
   (backup export, data import via JSON or CSV, sample data, reset) */
(function () {
  "use strict";
  const App = window.App;
  const esc = App.esc;
  const UI = App.ui;

  /* ---------- updates + version ---------- */
  // The desktop app can install an update itself; the browser build can only
  // point at the download. Both share this card.
  function updatesCardHTML() {
    const U = App.updates;
    const auto = App.state().settings.auto_update_check !== false;
    const where = U.desktop ? "Desktop app" : "Browser";

    let statusHTML = "";
    if (!U.configured) {
      statusHTML = `<p class="small muted">Update checking isn't set up in this build.</p>`;
    } else if (U.status === "checking") {
      statusHTML = `<p class="small muted">Checking…</p>`;
    } else if (U.status === "available" && U.manifest) {
      statusHTML = `
        <p class="small mb-2" style="color:var(--accent-soft-ink)">
          ${App.icon("download")} Version ${esc(U.manifest.version)} is available${U.manifest.released ? ` · released ${esc(U.manifest.released)}` : ""}
        </p>
        ${U.manifest.notes.length ? `<ul class="upd-notes mb-3">${U.manifest.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}`;
    } else if (U.status === "current") {
      statusHTML = `<p class="small mb-2" style="color:var(--good-ink)">${App.icon("checkCircle")} You're on the latest version</p>`;
    } else if (U.status === "error") {
      statusHTML = `<p class="small mb-2" style="color:var(--warning-ink)">${App.icon("alertTri")} ${esc(U.error)}</p>`;
    }

    const canInstall = U.status === "available" && U.manifest;
    return `
      <div class="card card-pad">
        <div class="card-title mb-1">Updates</div>
        <p class="card-sub mb-3">
          ${esc(App.state().settings.appName || "IB Tracker")} ${esc(U.version)} · ${where}.
          ${U.desktop
            ? "Updates install in place and never touch your tasks, sessions or settings — nothing is downloaded until you say so."
            : "A web page can't update itself, so this build tells you when a new version is out and links to the download."}
        </p>
        ${statusHTML}
        <div class="row wrap" style="gap:8px">
          <button class="btn btn-outline" data-check-update ${U.configured ? "" : "disabled"}>
            ${App.icon("rotate")} Check for updates
          </button>
          ${canInstall ? `<button class="btn btn-primary" data-install-update>
            ${App.icon("download")} ${U.desktop ? "Update &amp; restart" : "Open download page"}
          </button>` : ""}
        </div>
        ${U.configured ? `
          <hr class="divider">
          <div class="field">
            <label>Check automatically</label>
            <p class="hint mb-2">Once a day in the background. You always get the final say before anything installs.</p>
            <div class="theme-picker">
              ${[["on", "On"], ["off", "Off"]].map(([v, label]) => `
                <button class="theme-opt ${(auto ? "on" : "off") === v ? "active" : ""}" data-auto-update="${v}">
                  <span>${label}</span>
                </button>`).join("")}
            </div>
          </div>
          <p class="small muted mt-2">Last checked: ${esc(U.lastCheckLabel())}</p>` : ""}
      </div>`;
  }

  /* ---------- licence ---------- */
  function licenseCardHTML() {
    const L = App.license;
    const D = App.dates;
    const has = L.status === "licensed" || L.status === "expired";

    let statusHTML;
    if (L.status === "licensed") {
      const left = L.daysLeft();
      const soon = left !== Infinity && left <= 30;
      statusHTML = `
        <p class="small mb-2" style="color:var(--good-ink)">
          ${App.icon("checkCircle")} ${esc(L.tierLabel())}${L.name ? ` · ${esc(L.name)}` : ""}
        </p>
        <p class="small ${soon ? "" : "muted"}" ${soon ? 'style="color:var(--warning-ink)"' : ""}>
          ${L.isLifetime()
            ? "Never expires."
            : `Runs until ${esc(D.fmtMed(L.expiry))} — ${left} day${left === 1 ? "" : "s"} left.`}
        </p>`;
    } else if (L.status === "expired") {
      statusHTML = `<p class="small mb-2" style="color:var(--warning-ink)">
        ${App.icon("alertTri")} ${esc(L.reason)} The app is read-only until you add a current key.</p>`;
    } else if (L.status === "invalid") {
      statusHTML = `<p class="small mb-2" style="color:var(--danger-ink)">${App.icon("alertTri")} ${esc(L.reason)}</p>`;
    } else {
      statusHTML = `<p class="small muted mb-2">No licence key yet — the app is read-only.</p>`;
    }

    return `
      <div class="card card-pad">
        <div class="card-title mb-1">Licence</div>
        <p class="card-sub mb-3">
          A key unlocks editing. Reading, searching, reports and
          <strong>Export backup</strong> always work, with or without one — your
          data is yours either way.
        </p>
        ${statusHTML}
        <div class="field mt-3">
          <label>${has ? "Replace your key" : "Enter your key"}</label>
          <textarea class="input" rows="3" data-license-input spellcheck="false"
            style="font-family:var(--mono,ui-monospace,Menlo,monospace);font-size:12px"
            placeholder="IBT1.…"></textarea>
        </div>
        <div class="row wrap" style="gap:8px">
          <button class="btn btn-primary" data-license-save>${App.icon("checkCircle")} Activate</button>
          ${has ? `<button class="btn btn-ghost" data-license-remove>Remove key</button>` : ""}
        </div>
      </div>`;
  }

  function readFileAsText(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = () => reject(new Error("Couldn't read the file"));
      r.readAsText(file);
    });
  }

  function summaryText(summary) {
    const parts = Object.entries(summary.counts)
      .filter(([, n]) => n)
      .map(([k, n]) => `${n} ${k === "busyBlocks" ? "busy blocks" : k === "savedFilters" ? "saved views" : k}`);
    return parts.length ? "Imported " + parts.join(", ") : "Nothing imported";
  }

  function openImportModal() {
    UI.openModal({
      title: "Import data",
      size: "lg",
      body: `
        <p class="muted small mb-4" style="line-height:1.55">
          Restore a <strong>backup file</strong> made by this app, or bring data in from another
          tracker as a <strong>JSON export</strong> (common field names are understood automatically)
          or <strong>CSV files</strong> exported one entity at a time.
        </p>
        <div class="field">
          <label>How should imported records be applied?</label>
          ${UI.selectHTML("mode", [["merge", "Merge — add to what's already here (same IDs get updated)"], ["replace", "Replace — wipe current data first"]], "merge")}
        </div>
        <hr class="divider">
        <div class="field">
          <label>JSON file (backup or full export)</label>
          <input class="input" type="file" accept=".json,application/json" data-json-file style="padding-top:6px">
        </div>
        <hr class="divider">
        <div class="field">
          <label>CSV file (one entity at a time)</label>
          <div class="row" style="gap:8px">
            ${UI.selectHTML("csvType", [
              ["tasks", "Tasks"], ["subtasks", "Sub-tasks"], ["subjects", "Subjects"],
              ["grades", "Grades"], ["timersessions", "Timer sessions"], ["busyblocks", "Busy blocks"],
              ["tasktemplates", "Templates"], ["savedfilters", "Saved views"],
              ["universitycourses", "University courses"], ["usersettings", "Settings"],
            ], "tasks", 'style="width:190px"')}
            <input class="input" type="file" accept=".csv,text/csv" data-csv-file style="padding-top:6px;flex:1">
          </div>
        </div>
        <div data-import-result class="mt-3"></div>`,
      foot: `<button class="btn btn-outline" data-close>Close</button>
             <button class="btn btn-primary" data-do-import>${App.icon("upload")} Import</button>`,
      onMount(el, handle) {
        const resultEl = el.querySelector("[data-import-result]");
        el.querySelector("[data-do-import]").addEventListener("click", async () => {
          const mode = el.querySelector('[name="mode"]').value;
          const jsonFile = el.querySelector("[data-json-file]").files[0];
          const csvFile = el.querySelector("[data-csv-file]").files[0];
          if (!jsonFile && !csvFile) {
            App.toast("Choose a JSON or CSV file first", "error");
            return;
          }
          try {
            let summary;
            if (jsonFile) {
              const text = await readFileAsText(jsonFile);
              let obj;
              try { obj = JSON.parse(text); }
              catch (e) { throw new Error("That file isn't valid JSON."); }
              summary = App.importJSON(obj, mode);
            } else {
              const text = await readFileAsText(csvFile);
              summary = App.importCSV(text, el.querySelector('[name="csvType"]').value, mode);
            }
            const ok = Object.values(summary.counts).some((n) => n);
            resultEl.innerHTML = `
              <div class="chip ${ok ? "chip-good" : "chip-warning"}" style="font-size:12.5px;padding:6px 12px">${esc(summaryText(summary))}</div>
              ${summary.errors.length ? `<p class="small mt-2" style="color:var(--warning-ink)">${summary.errors.map(esc).join("<br>")}</p>` : ""}`;
            if (ok) App.toast("Import complete");
          } catch (err) {
            resultEl.innerHTML = `<div class="chip chip-danger" style="font-size:12.5px;padding:6px 12px">${esc(err.message)}</div>`;
          }
        });
      },
    });
  }

  App.pages.settings = {
    title: "Settings",
    render() {
      const s = App.state();
      const subjects = s.subjects;
      const hours = s.settings.hours_per_day;
      const theme = s.settings.theme || "auto";
      const counts = {
        tasks: s.tasks.length, sessions: s.sessions.length,
        subjects: s.subjects.length, courses: s.courses.length,
      };

      return `
        <div class="page narrow">
          ${UI.pageHead("Settings", "Subjects, study hours, appearance and your data")}
          <div class="stack">

            <div class="card card-pad">
              <div class="card-title">Subjects</div>
              <p class="card-sub mb-3">These appear in dropdowns across the app. Give each one an emoji and a color — they follow the subject everywhere: task chips, the Scheduler, the Calendar and Analytics.</p>
              <div class="row mb-3" style="gap:8px">
                <input class="input" data-new-subject placeholder="e.g. Physics" style="flex:1">
                ${UI.selectHTML("new_subject_level", [["", "Level"], ["HL", "HL"], ["SL", "SL"]], "", 'data-new-subject-level style="width:84px"')}
                <button class="btn btn-primary" data-add-subject>${App.icon("plus")} Add</button>
              </div>
              <div data-subject-list>
                ${subjects.length ? subjects.map((sub) => {
                  const meta = App.subjectMeta(sub.name);
                  return `
                  <div class="subject-row" style="border-left:3px solid ${meta.color}">
                    <input class="subj-emoji-input" data-subj-emoji="${esc(sub.id)}" value="${esc(meta.emoji)}"
                      maxlength="4" title="Emoji for ${esc(sub.name)}" aria-label="Emoji for ${esc(sub.name)}">
                    <span style="flex:1">${esc(sub.name)}</span>
                    ${UI.selectHTML("subj_level", [["", "Level"], ["HL", "HL"], ["SL", "SL"]], sub.level || "", `data-subj-level="${esc(sub.id)}" style="width:84px" aria-label="Level for ${esc(sub.name)}"`)}
                    <input type="color" class="subj-color-input" data-subj-color="${esc(sub.id)}" value="${esc(meta.color)}"
                      title="Color for ${esc(sub.name)}" aria-label="Color for ${esc(sub.name)}">
                    <button class="icon-btn danger" data-del-subject="${esc(sub.id)}" title="Remove">${App.icon("trash")}</button>
                  </div>`;
                }).join("") : `<p class="muted small">No subjects yet — add your six IB subjects</p>`}
              </div>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">Study capacity</div>
              <p class="card-sub mb-3">Used by the scheduler and the workload forecast</p>
              <div class="section-label">Available hours per day</div>
              ${App.DAY_KEYS.map((day, i) => `
                <div class="hours-row">
                  <label>${App.DAY_LABELS[i]}</label>
                  <div class="row" style="gap:7px">
                    <input class="input" type="number" min="0" max="16" step="0.5" data-hours="${day}" value="${hours[day] ?? 0}">
                    <span class="muted small" style="width:24px">hrs</span>
                  </div>
                </div>`).join("")}
              <hr class="divider">
              <div class="section-label">Work window</div>
              <div class="form-row">
                <div class="field">
                  <label>Earliest start</label>
                  <input class="input" type="number" min="0" max="23" data-work-start value="${s.settings.work_start_hour}">
                  <p class="hint" data-start-hint></p>
                </div>
                <div class="field">
                  <label>Latest end</label>
                  <input class="input" type="number" min="1" max="24" data-work-end value="${s.settings.work_end_hour}">
                  <p class="hint" data-end-hint></p>
                </div>
              </div>
              <button class="btn btn-primary btn-block" data-save-capacity>Save capacity</button>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">App name</div>
              <p class="card-sub mb-3">Shown in the sidebar, browser tab and printed reports.</p>
              <div class="row" style="gap:8px">
                <input class="input" data-app-name value="${esc(s.settings.appName || "IB Tracker")}" placeholder="IB Tracker" maxlength="40" style="flex:1">
              </div>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">IB exams</div>
              <p class="card-sub mb-3">Set when your exam session starts and the Dashboard shows a live countdown.</p>
              <div class="field" style="margin-bottom:0">
                <label>Exam session start date</label>
                <div class="row" style="gap:8px">
                  <input class="input" type="date" data-exam-date value="${esc(s.settings.exam_date || "")}" style="flex:1">
                  ${s.settings.exam_date ? `<button class="btn btn-outline" data-exam-clear>Clear</button>` : ""}
                </div>
                ${s.settings.exam_date && s.settings.exam_date >= App.dates.today()
                  ? `<p class="hint">${App.dates.diffDays(App.dates.today(), s.settings.exam_date)} days to go.</p>`
                  : s.settings.exam_date ? `<p class="hint">That date has passed.</p>` : ""}
              </div>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">Weekly goal</div>
              <p class="card-sub mb-3">A target for focused study each week. The Dashboard tracks your progress and it resets every Monday. Set to 0 to hide it.</p>
              <div class="field" style="margin-bottom:0">
                <label>Focused study hours per week</label>
                <div class="row" style="gap:7px;max-width:200px">
                  <input class="input" type="number" min="0" max="80" step="1" data-weekly-goal value="${s.settings.weekly_goal_hours ?? 10}">
                  <span class="muted small" style="align-self:center">h / week</span>
                </div>
              </div>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">Onboarding</div>
              <p class="card-sub mb-3">New here, or want a refresher on where everything lives?</p>
              <button class="btn btn-outline" data-replay-tour>${App.icon("sparkles")} Take the tour</button>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-3">Appearance</div>
              <div class="theme-picker">
                ${[["light", "Light", "sun"], ["dark", "Dark", "moon"], ["auto", "Auto", "monitor"]].map(([v, l, ic]) => `
                  <button class="theme-opt ${theme === v ? "active" : ""}" data-theme-opt="${v}">
                    ${App.icon(ic)} ${l}
                  </button>`).join("")}
              </div>
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">Coach</div>
              <p class="card-sub mb-3">The Coach page works offline out of the box. Add an OpenRouter API key to turn it into a full AI conversation — one key unlocks Claude, GPT, DeepSeek, Gemini and hundreds of other models.</p>
              <div class="section-label">Tone</div>
              <div class="theme-picker mb-4">
                ${[["warm", "Warm mentor", "sparkles"], ["direct", "No-nonsense", "zap"]].map(([v, l, ic]) => `
                  <button class="theme-opt ${(s.settings.coach_tone || "warm") === v ? "active" : ""}" data-coach-tone="${v}">
                    ${App.icon(ic)} ${l}
                  </button>`).join("")}
              </div>
              <div class="section-label">AI mode (optional)</div>
              <div class="field">
                <label>OpenRouter API key</label>
                <div class="row" style="gap:8px">
                  <input class="input" type="password" data-coach-key
                    placeholder="${s.settings.ai_api_key ? "•••••••••••••••••••• (key saved)" : "sk-or-…"}" style="flex:1">
                  <button class="btn btn-primary" data-coach-key-save>Save</button>
                  ${s.settings.ai_api_key ? `<button class="btn btn-danger-ghost" data-coach-key-remove>Remove</button>` : ""}
                </div>
                <p class="hint">Get a key at openrouter.ai/keys. It's stored only in this browser, is never included in backups, and messages cost a fraction of a cent each. With a key set, your study data is sent to OpenRouter (and the model provider you pick) when you chat with the coach.</p>
              </div>
              ${s.settings.ai_api_key ? `
                <div class="field">
                  <label>AI model</label>
                  ${UI.selectHTML("ai_model", [
                    ["anthropic/claude-3.7-sonnet", "Claude 3.7 Sonnet"],
                    ["openai/gpt-4o", "GPT-4o"],
                    ["deepseek/deepseek-r1", "DeepSeek R1"],
                    ["google/gemini-2.0-flash-001", "Gemini 2.0 Flash"],
                    ["custom", "Custom — paste a model ID"],
                  ], App.coach.isCustomModel(s.settings.ai_model) ? "custom" : (s.settings.ai_model || "anthropic/claude-3.7-sonnet"), 'data-ai-model')}
                </div>
                <div class="field" data-custom-model-field ${App.coach.isCustomModel(s.settings.ai_model) ? "" : "hidden"}>
                  <label>Custom model ID</label>
                  <input class="input" data-ai-model-custom value="${App.coach.isCustomModel(s.settings.ai_model) ? esc(s.settings.ai_model) : ""}" placeholder="e.g. mistralai/mistral-large">
                  <p class="hint">Any <a href="https://openrouter.ai/models" target="_blank" rel="noopener">OpenRouter model ID</a>, exactly as listed there.</p>
                </div>` : ""}
            </div>

            <div class="card card-pad">
              <div class="card-title mb-1">Your data</div>
              <p class="card-sub mb-2">
                Everything lives privately in this browser (${counts.tasks} tasks, ${counts.sessions} sessions,
                ${counts.subjects} subjects, ${counts.courses} courses). Export a backup regularly — especially before clearing browser data.
              </p>
              <p class="small mb-3" style="color:${App.backupOverdue() ? "var(--warning-ink)" : "var(--ink-3)"}">
                ${App.icon(App.backupOverdue() ? "alertTri" : "checkCircle")} Last backup: ${esc(App.lastBackupLabel())}
              </p>
              <div class="row wrap" style="gap:8px">
                <button class="btn btn-outline" data-export>${App.icon("download")} Export backup</button>
                <button class="btn btn-outline" data-import>${App.icon("upload")} Import data</button>
                <button class="btn btn-outline" data-sample>${App.icon("sparkles")} Load sample data</button>
              </div>
              <hr class="divider">
              <button class="btn btn-danger-ghost" data-erase>${App.icon("trash")} Erase all data</button>
            </div>

            ${licenseCardHTML()}
            ${updatesCardHTML()}
          </div>
        </div>`;
    },

    mount(el) {
      // subjects
      const input = el.querySelector("[data-new-subject]");
      const newLevelSel = el.querySelector("[data-new-subject-level]");
      const add = () => {
        const name = input.value.trim();
        if (!name) return;
        const created = App.createSubject(name, newLevelSel.value);
        if (!created) { App.toast("That subject already exists", "error"); return; }
        input.value = ""; newLevelSel.value = "";
        App.toast("Subject added");
      };
      el.querySelector("[data-add-subject]").addEventListener("click", add);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
      el.querySelectorAll("[data-subj-level]").forEach((sel) =>
        sel.addEventListener("change", () => {
          App.setSubjectLevel(sel.dataset.subjLevel, sel.value);
          App.toast("Subject level updated");
        }));
      el.querySelectorAll("[data-del-subject]").forEach((b) =>
        b.addEventListener("click", async () => {
          const sub = App.state().subjects.find((x) => x.id === b.dataset.delSubject);
          const inUse = App.state().tasks.filter((t) => t.subject_name === sub.name && !t.completed).length;
          const ok = await UI.confirm({
            title: "Remove subject?",
            message: inUse
              ? `“${sub.name}” still has ${inUse} open task${inUse > 1 ? "s" : ""}. They keep their subject label; it just leaves the dropdowns.`
              : `“${sub.name}” will be removed from dropdowns.`,
            confirmLabel: "Remove",
          });
          if (ok) { App.deleteSubject(sub.id); App.toast("Subject removed"); }
        }));

      // subject emoji + color customization
      el.querySelectorAll("[data-subj-emoji]").forEach((inp) =>
        inp.addEventListener("change", () => {
          App.updateSubject(inp.dataset.subjEmoji, { emoji: inp.value.trim().slice(0, 8) });
          App.toast("Subject emoji updated");
        }));
      el.querySelectorAll("[data-subj-color]").forEach((inp) =>
        inp.addEventListener("change", () => {
          App.updateSubject(inp.dataset.subjColor, { color: inp.value });
          App.toast("Subject color updated");
        }));

      // capacity
      const hint = () => {
        const st = parseInt(el.querySelector("[data-work-start]").value) || 0;
        const en = parseInt(el.querySelector("[data-work-end]").value) || 0;
        const fmt = (h) => `${h % 12 === 0 ? 12 : h % 12} ${h < 12 || h === 24 ? "AM" : "PM"}`;
        el.querySelector("[data-start-hint]").textContent = fmt(st);
        el.querySelector("[data-end-hint]").textContent = fmt(en);
      };
      el.querySelector("[data-work-start]").addEventListener("input", hint);
      el.querySelector("[data-work-end]").addEventListener("input", hint);
      hint();
      el.querySelector("[data-save-capacity]").addEventListener("click", () => {
        const hours = {};
        el.querySelectorAll("[data-hours]").forEach((i) => {
          hours[i.dataset.hours] = App.clamp(parseFloat(i.value) || 0, 0, 16);
        });
        const start = App.clamp(parseInt(el.querySelector("[data-work-start]").value) || 8, 0, 23);
        let end = App.clamp(parseInt(el.querySelector("[data-work-end]").value) || 22, 1, 24);
        if (end <= start) {
          App.toast("The work window must end after it starts", "error");
          return;
        }
        App.update((s) => {
          s.settings.hours_per_day = hours;
          s.settings.work_start_hour = start;
          s.settings.work_end_hour = end;
        });
        App.toast("Capacity saved");
      });

      // app name
      el.querySelector("[data-app-name]").addEventListener("change", (e) => {
        const name = e.target.value.trim() || "IB Tracker";
        App.update((s) => { s.settings.appName = name; });
        App.toast("App name updated");
      });

      // exam date
      el.querySelector("[data-exam-date]").addEventListener("change", (e) => {
        const v = /^\d{4}-\d{2}-\d{2}$/.test(e.target.value) ? e.target.value : "";
        App.update((s) => { s.settings.exam_date = v; });
        App.toast(v ? "Exam date saved" : "Exam date cleared");
      });
      const examClear = el.querySelector("[data-exam-clear]");
      if (examClear) examClear.addEventListener("click", () => {
        App.update((s) => { s.settings.exam_date = ""; });
        App.toast("Exam date cleared");
      });

      // weekly goal
      el.querySelector("[data-weekly-goal]").addEventListener("change", (e) => {
        const v = App.clamp(Math.round(Number(e.target.value) || 0), 0, 80);
        App.update((s) => { s.settings.weekly_goal_hours = v; });
        App.toast(v ? "Weekly goal saved" : "Weekly goal hidden");
      });

      // onboarding tour
      el.querySelector("[data-replay-tour]").addEventListener("click", () => App.tour.start());

      // theme
      el.querySelectorAll("[data-theme-opt]").forEach((b) =>
        b.addEventListener("click", () => {
          App.update((s) => { s.settings.theme = b.dataset.themeOpt; });
          App.applyTheme();
        }));

      // coach
      el.querySelectorAll("[data-coach-tone]").forEach((b) =>
        b.addEventListener("click", () => {
          App.update((s) => { s.settings.coach_tone = b.dataset.coachTone; });
        }));
      el.querySelector("[data-coach-key-save]").addEventListener("click", () => {
        const val = el.querySelector("[data-coach-key]").value.trim();
        if (!val) { App.toast("Paste a key first", "error"); return; }
        App.update((s) => { s.settings.ai_api_key = val; });
        App.toast("API key saved — the coach is now AI-powered");
      });
      const keyRemove = el.querySelector("[data-coach-key-remove]");
      if (keyRemove) keyRemove.addEventListener("click", () => {
        App.update((s) => { s.settings.ai_api_key = ""; });
        App.toast("API key removed — coach is back to built-in mode");
      });
      const modelSel = el.querySelector("[data-ai-model]");
      const customField = el.querySelector("[data-custom-model-field]");
      const customInput = el.querySelector("[data-ai-model-custom]");
      if (modelSel) modelSel.addEventListener("change", () => {
        if (modelSel.value === "custom") {
          customField.hidden = false;
          customInput.focus();
          return;
        }
        customField.hidden = true;
        App.update((s) => { s.settings.ai_model = modelSel.value; });
        App.toast("AI model updated");
      });
      if (customInput) customInput.addEventListener("change", () => {
        const val = customInput.value.trim();
        if (!val) return;
        App.update((s) => { s.settings.ai_model = val; });
        App.toast("AI model updated");
      });

      // data
      el.querySelector("[data-export]").addEventListener("click", () => {
        App.exportBackup();
        App.toast("Backup downloaded");
        App.render(); // refresh the "Last backup" status line
      });
      el.querySelector("[data-import]").addEventListener("click", openImportModal);
      el.querySelector("[data-sample]").addEventListener("click", async () => {
        const hasData = App.state().tasks.length || App.state().sessions.length;
        if (hasData) {
          const ok = await UI.confirm({
            title: "Load sample data?",
            message: "This replaces everything currently in the app with demo data. Export a backup first if you need your data.",
            confirmLabel: "Replace with sample",
          });
          if (!ok) return;
        }
        App.loadSampleData();
        App.toast("Sample data loaded");
      });
      el.querySelector("[data-erase]").addEventListener("click", async () => {
        const ok = await UI.confirm({
          title: "Erase all data?",
          message: "Every task, session, grade and setting will be permanently deleted from this browser. This cannot be undone — consider exporting a backup first.",
          confirmLabel: "Erase everything",
        });
        if (!ok) return;
        const fresh = App.emptyData();
        fresh.ui.welcomed = false;
        App.replaceState(fresh);
        App.applyTheme();
        App.navigate("dashboard");
        App.toast("All data erased");
      });

      // licence
      const licSave = el.querySelector("[data-license-save]");
      if (licSave) licSave.addEventListener("click", async () => {
        const box = el.querySelector("[data-license-input]");
        const raw = (box.value || "").trim();
        if (!raw) { App.toast("Paste your licence key first", "error"); return; }
        const res = await App.license.apply(raw);
        if (res.ok && !res.expired) {
          box.value = "";
          App.toast("Licence activated — thank you");
        } else if (res.ok && res.expired) {
          box.value = "";
          App.toast("That key has already expired", "error");
        } else {
          App.toast(res.reason || "That key isn't valid", "error");
        }
        App.render();
      });
      const licRemove = el.querySelector("[data-license-remove]");
      if (licRemove) licRemove.addEventListener("click", async () => {
        const ok = await UI.confirm({
          title: "Remove your licence key?",
          message: "The app becomes read-only until you enter a key again. Nothing is deleted, and you can still export a backup.",
          confirmText: "Remove",
        });
        if (!ok) return;
        App.license.remove();
        App.toast("Licence key removed");
        App.render();
      });

      // updates
      const checkBtn = el.querySelector("[data-check-update]");
      if (checkBtn) checkBtn.addEventListener("click", async () => {
        const status = await App.updates.check({ manual: true });
        if (status === "current") App.toast("You're on the latest version");
        else if (status === "error") App.toast(App.updates.error, "error");
      });
      const installBtn = el.querySelector("[data-install-update]");
      if (installBtn) installBtn.addEventListener("click", () => App.updates.install());
      el.querySelectorAll("[data-auto-update]").forEach((b) =>
        b.addEventListener("click", () => {
          App.update((s) => { s.settings.auto_update_check = b.dataset.autoUpdate === "on"; });
        }));
    },
  };
})();
