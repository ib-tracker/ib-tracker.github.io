/* ui.js — toasts, modals, popovers, form helpers, sidebar */
(function () {
  "use strict";
  const App = window.App;
  const esc = App.esc;
  const UI = (App.ui = {});

  /* ---------- toast ---------- */
  App.toast = function (msg, type) {
    const root = document.getElementById("toast-root");
    if (!root) return;
    const el = document.createElement("div");
    el.className = "toast " + (type || "success");
    el.innerHTML = (type === "error" ? App.icon("alertCircle") : App.icon("checkCircle")) + `<span></span>`;
    el.querySelector("span").textContent = msg;
    root.appendChild(el);
    setTimeout(() => { el.classList.add("leaving"); setTimeout(() => el.remove(), 300); }, 2600);
  };

  /* ---------- modal (imperative, stacked) ---------- */
  const modalStack = [];

  // openModal({title, body, foot, size, onMount, onClose}) -> {el, close}
  UI.openModal = function (opts) {
    const root = document.getElementById("modal-root");
    const scrim = document.createElement("div");
    scrim.className = "modal-scrim";
    scrim.innerHTML = `
      <div class="modal ${opts.size === "sm" ? "modal-sm" : opts.size === "lg" ? "modal-lg" : ""}" role="dialog" aria-modal="true">
        <div class="modal-head">
          <h2>${esc(opts.title || "")}</h2>
          <button class="icon-btn" data-close aria-label="Close">${App.icon("x")}</button>
        </div>
        <div class="modal-body">${opts.body || ""}</div>
        ${opts.foot ? `<div class="modal-foot${opts.footSplit ? " split" : ""}">${opts.foot}</div>` : ""}
      </div>`;
    root.appendChild(scrim);

    const handle = {
      el: scrim,
      close() {
        const i = modalStack.indexOf(handle);
        if (i >= 0) modalStack.splice(i, 1);
        scrim.remove();
        if (opts.onClose) opts.onClose();
      },
    };
    modalStack.push(handle);

    scrim.addEventListener("mousedown", (e) => { if (e.target === scrim) handle.close(); });
    scrim.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => handle.close()));
    if (opts.onMount) opts.onMount(scrim, handle);
    const firstInput = scrim.querySelector("input:not([type=checkbox]), textarea, select");
    if (firstInput) setTimeout(() => firstInput.focus(), 60);
    return handle;
  };

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modalStack.length) {
      modalStack[modalStack.length - 1].close();
    }
  });

  /* ---------- confirm dialog ---------- */
  UI.confirm = function (opts) {
    return new Promise((resolve) => {
      let settled = false;
      const h = UI.openModal({
        title: opts.title || "Are you sure?",
        size: "sm",
        body: `<p class="muted" style="font-size:13px; line-height:1.5;">${esc(opts.message || "This action cannot be undone.")}</p>`,
        foot: `
          <button class="btn btn-outline" data-close>Cancel</button>
          <button class="btn ${opts.danger === false ? "btn-primary" : "btn-danger"}" data-confirm>${esc(opts.confirmLabel || "Delete")}</button>`,
        onMount(el, handle) {
          el.querySelector("[data-confirm]").addEventListener("click", () => {
            settled = true; handle.close(); resolve(true);
          });
        },
        onClose() { if (!settled) resolve(false); },
      });
      return h;
    });
  };

  /* ---------- popover (one at a time) ---------- */
  let openPop = null;
  UI.closePopovers = function () {
    if (openPop) { openPop.remove(); openPop = null; }
  };
  UI.togglePopover = function (anchorEl, contentHTML) {
    if (openPop && openPop._anchor === anchorEl) { UI.closePopovers(); return; }
    UI.closePopovers();
    const pop = document.createElement("div");
    pop.className = "popover";
    pop.innerHTML = contentHTML;
    pop._anchor = anchorEl;
    anchorEl.closest(".pop-anchor").appendChild(pop);
    openPop = pop;
    // keep inside the viewport horizontally
    requestAnimationFrame(() => {
      const r = pop.getBoundingClientRect();
      if (r.left < 8) pop.style.transform = `translateX(calc(-50% + ${8 - r.left}px))`;
      else if (r.right > window.innerWidth - 8) pop.style.transform = `translateX(calc(-50% - ${r.right - window.innerWidth + 8}px))`;
    });
  };
  document.addEventListener("click", (e) => {
    if (openPop && !e.target.closest(".popover") && !e.target.closest("[data-popover-trigger]")) UI.closePopovers();
  });

  /* ---------- form helpers ---------- */
  UI.selectHTML = function (name, options, selected, attrs) {
    const opts = options.map(([v, label]) =>
      `<option value="${esc(v)}"${String(v) === String(selected) ? " selected" : ""}>${esc(label)}</option>`).join("");
    return `<select class="select" name="${esc(name)}" ${attrs || ""}>${opts}</select>`;
  };

  UI.subjectOptions = function (selected, allowNone) {
    const subs = App.state().subjects.map((s) => [s.name, s.name]);
    const opts = allowNone ? [["", "None"], ...subs] : [["", "Select subject…"], ...subs];
    return opts;
  };

  UI.categoryOptions = () => Object.entries(App.CATEGORIES).map(([k, v]) => [k, v.label]);
  UI.priorityOptions = () => Object.entries(App.PRIORITIES).map(([k, v]) => [k, v.label]);

  UI.readForm = function (rootEl) {
    const out = {};
    rootEl.querySelectorAll("input[name], select[name], textarea[name]").forEach((el) => {
      if (el.type === "checkbox") out[el.name] = el.checked;
      else if (el.type === "number") out[el.name] = el.value === "" ? "" : Number(el.value);
      else out[el.name] = el.value;
    });
    return out;
  };

  /* ---------- chips ---------- */
  UI.categoryChip = function (cat) {
    const c = App.CATEGORIES[cat];
    if (!c) return "";
    return `<span class="chip" style="background:var(--${c.cls});color:var(--${c.cls}-ink)">${esc(c.label)}</span>`;
  };
  UI.priorityChip = function (pri) {
    const p = App.PRIORITIES[pri] || App.PRIORITIES.medium;
    return `<span class="chip ${p.chip}">${esc(p.label)}</span>`;
  };
  UI.subjectChip = function (name) {
    if (!name) return "";
    const meta = App.subjectMeta(name);
    return `<span class="chip subj-chip" style="background:color-mix(in srgb, ${meta.color} 15%, var(--surface));color:color-mix(in srgb, ${meta.color} 62%, var(--ink) 38%)">${meta.emoji ? meta.emoji + " " : ""}${esc(name)}</span>`;
  };
  // "🧮 Math AA HL" — emoji-prefixed label for headings and reports
  UI.subjectLabel = function (name) {
    if (!name) return "";
    const meta = App.subjectMeta(name);
    return `${meta.emoji ? meta.emoji + " " : ""}${esc(name)}`;
  };
  UI.dueChip = function (task) {
    if (!task.due_date) return "";
    if (App.isOverdue(task)) return `<span class="chip chip-danger">${App.icon("calendar")} Overdue · ${esc(App.dates.fmtShort(task.due_date))}</span>`;
    if (App.isDueToday(task)) return `<span class="chip chip-warning">${App.icon("calendar")} Today</span>`;
    return `<span class="chip chip-plain">${App.icon("calendar")} ${esc(App.dates.fmtShort(task.due_date))}</span>`;
  };

  /* ---------- page head ---------- */
  UI.pageHead = function (title, sub, actionsHTML) {
    return `
      <div class="page-head">
        <div>
          <h1>${esc(title)}</h1>
          ${sub ? `<p class="sub">${esc(sub)}</p>` : ""}
        </div>
        ${actionsHTML ? `<div class="row wrap">${actionsHTML}</div>` : ""}
      </div>`;
  };

  UI.emptyState = function (icon, title, sub, actionHTML) {
    return `
      <div class="empty">
        ${App.icon(icon)}
        <div class="empty-title">${esc(title)}</div>
        ${sub ? `<div style="margin-top:3px">${esc(sub)}</div>` : ""}
        ${actionHTML || ""}
      </div>`;
  };

  UI.spinnerless = true; // everything is synchronous — no loading states needed

  /* ---------- sidebar ---------- */
  const NAV = [
    { group: "Overview", items: [
      { page: "dashboard", label: "Dashboard", icon: "dashboard" },
      { page: "timeline", label: "Timeline", icon: "clock" },
      { page: "calendar", label: "Calendar", icon: "calendar" },
    ]},
    { group: "Study", items: [
      { page: "study", label: "Study Session", icon: "timer" },
      { page: "focus", label: "Focus", icon: "target" },
      { page: "scheduler", label: "Scheduler", icon: "calendarClock" },
      { page: "analytics", label: "Analytics", icon: "chart" },
      { page: "coach", label: "Coach", icon: "messageCircle" },
    ]},
    { group: "IB", items: [
      { page: "subjects", label: "Subjects", icon: "book" },
      { page: "core", label: "Core Requirements", icon: "award" },
      { page: "grades", label: "Grades", icon: "gradcap" },
      { page: "university", label: "University", icon: "building" },
    ]},
    { group: "Workspace", items: [
      { page: "templates", label: "Templates", icon: "template" },
      { page: "notes", label: "Notes", icon: "fileText" },
      { page: "settings", label: "Settings", icon: "settings" },
    ]},
  ];

  App.renderSidebar = function () {
    const sb = document.getElementById("sidebar");
    if (!sb) return;
    const cur = App.currentPage();
    const s = App.state();
    const openCount = s.tasks.filter((t) => !t.completed).length;
    const overdueCount = s.tasks.filter((t) => App.isOverdue(t)).length;

    sb.innerHTML = `
      <div class="sidebar-brand">
        <div class="brand-mark">IB</div>
        <div>
          <div class="brand-name">${esc(s.settings.appName || "IB Tracker")}</div>
          <div class="brand-sub">IB Diploma</div>
        </div>
      </div>
      <button class="sidebar-search" data-open-search>
        ${App.icon("search")}
        <span>Search or add…</span>
        <span class="kbd-hint">${/Mac|iPhone|iPad/.test(navigator.platform) ? "⌘K" : "Ctrl K"}</span>
      </button>
      <nav class="sidebar-nav">
        ${NAV.map((g) => `
          <div class="nav-group-label">${esc(g.group)}</div>
          ${g.items.map((item) => {
            let count = "";
            if (item.page === "timeline" && openCount) count = `<span class="nav-count">${openCount}</span>`;
            if (item.page === "dashboard" && overdueCount) count = `<span class="nav-count" style="background:var(--danger-soft);color:var(--danger-ink)">${overdueCount}</span>`;
            return `
              <a class="nav-item ${cur === item.page ? "active" : ""}" href="#/${item.page}" data-nav>
                ${App.icon(item.icon)}
                <span>${esc(item.label)}</span>
                ${count}
              </a>`;
          }).join("")}
        `).join("")}
      </nav>
      <div class="sidebar-foot">
        <button class="btn btn-primary btn-block" data-action="new-task">${App.icon("plus")} Add Task</button>
      </div>`;

    sb.querySelectorAll("[data-nav]").forEach((a) =>
      a.addEventListener("click", () => UI.closeSidebar()));
    sb.querySelector('[data-action="new-task"]').addEventListener("click", () => {
      UI.closeSidebar();
      App.taskui.openTaskModal(null);
    });
    sb.querySelector("[data-open-search]").addEventListener("click", () => {
      UI.closeSidebar();
      App.search.open();
    });

    const mh = document.getElementById("mobile-header");
    mh.innerHTML = `
      <button class="icon-btn" data-open-sidebar aria-label="Menu">${App.icon("menu")}</button>
      <div class="row" style="gap:8px">
        <div class="brand-mark" style="width:26px;height:26px;border-radius:8px;font-size:11px">IB</div>
        <span style="font-weight:700;font-size:14px">${esc(s.settings.appName || "IB Tracker")}</span>
      </div>`;
    mh.querySelector("[data-open-sidebar]").addEventListener("click", () => UI.openSidebar());
  };

  UI.openSidebar = function () {
    document.getElementById("sidebar").classList.add("open");
    document.getElementById("sidebar-scrim").classList.add("show");
  };
  UI.closeSidebar = function () {
    document.getElementById("sidebar").classList.remove("open");
    document.getElementById("sidebar-scrim").classList.remove("show");
  };
  document.getElementById("sidebar-scrim").addEventListener("click", () => UI.closeSidebar());

  /* ---------- level-up popup ---------- */
  App.showLevelUp = function (level) {
    document.querySelectorAll(".levelup-scrim").forEach((n) => n.remove());
    const el = document.createElement("div");
    el.className = "levelup-scrim";
    el.innerHTML = `
      <div class="levelup-card">
        <div class="levelup-emoji">🎉</div>
        <div class="levelup-title">LEVEL UP!</div>
        <div class="levelup-level">You reached Level ${level}!</div>
      </div>`;
    document.body.appendChild(el);
    const dismiss = () => el.remove();
    el.addEventListener("click", dismiss);
    setTimeout(dismiss, 2000);
  };

  /* ---------- chime (WebAudio, no asset) ---------- */
  // a short two-note ding; `up` picks the flavour (true = pleasant rising cue)
  App.chime = function (up) {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      const ac = new Ctx();
      const notes = up === false ? [520, 392] : [523, 784]; // break: falling · done/focus: rising
      notes.forEach((freq, i) => {
        const o = ac.createOscillator(), g = ac.createGain();
        o.connect(g); g.connect(ac.destination);
        o.type = "sine";
        o.frequency.value = freq;
        const t0 = ac.currentTime + i * 0.18;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(0.22, t0 + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.5);
        o.start(t0); o.stop(t0 + 0.52);
      });
      setTimeout(() => { try { ac.close(); } catch (e) { /* ignore */ } }, 1200);
    } catch (e) { /* audio may be blocked until first interaction — fine */ }
  };

  /* ---------- confetti (dependency-free) ---------- */
  App.confetti = function () {
    const canvas = document.createElement("canvas");
    canvas.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:400";
    canvas.width = innerWidth; canvas.height = innerHeight;
    document.body.appendChild(canvas);
    const ctx = canvas.getContext("2d");
    const colors = ["#4f46e5", "#7c6ff0", "#2a78d6", "#1baf7a", "#eda100", "#e87ba4"];
    const parts = [];
    for (let i = 0; i < 70; i++) {
      parts.push({
        x: innerWidth / 2 + (Math.random() - 0.5) * 200,
        y: innerHeight * 0.68,
        vx: (Math.random() - 0.5) * 11,
        vy: -(6 + Math.random() * 9),
        size: 5 + Math.random() * 5,
        color: colors[(Math.random() * colors.length) | 0],
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.3,
      });
    }
    let frame = 0;
    (function tick() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = false;
      for (const p of parts) {
        p.x += p.vx; p.y += p.vy; p.vy += 0.35; p.rot += p.vr;
        if (p.y < innerHeight + 30) alive = true;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, 1 - frame / 90);
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        ctx.restore();
      }
      frame++;
      if (alive && frame < 100) requestAnimationFrame(tick);
      else canvas.remove();
    })();
  };
})();
