/* core.js — store, persistence, dates, router, tiny utilities */
(function () {
  "use strict";
  const App = (window.App = window.App || {});

  /* ---------- utilities ---------- */
  App.uid = function () {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
  };

  App.esc = function (s) {
    if (s === null || s === undefined) return "";
    return String(s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };

  App.escAttr = App.esc;

  /* ---------- rich-text sanitizer (Notes) ----------
     Note bodies are real HTML, so anything pasted in — or restored from a
     backup file — has to be cleaned before it reaches the DOM. Parsing happens
     via DOMParser, which builds an INERT document: no scripts run and no images
     load while we inspect it. (A detached div + innerHTML is NOT inert — an
     <img onerror> fires there — so never use that for untrusted HTML.)
     Whitelist approach: keep basic formatting, drop everything else. */
  const KEEP_TAGS = new Set(["B","STRONG","I","EM","U","S","STRIKE","DEL","H1","H2","H3","H4","H5","H6",
    "UL","OL","LI","A","BR","DIV","P","CODE","PRE","BLOCKQUOTE","HR"]);
  const DROP_TAGS = new Set(["SCRIPT","STYLE","NOSCRIPT","TEMPLATE","IFRAME","OBJECT","EMBED","SVG","MATH",
    "IMG","VIDEO","AUDIO","SOURCE","CANVAS","FORM","INPUT","BUTTON","SELECT","TEXTAREA","LINK","META","BASE"]);
  const SAFE_URL = /^(https?:|mailto:)/i;

  App.sanitizeHtml = function (html) {
    const src = String(html || "");
    if (!src) return "";
    const doc = new DOMParser().parseFromString(src, "text/html");
    const walk = (node) => {
      // iterate over a copy — we mutate the tree as we go
      for (const child of Array.from(node.childNodes)) {
        if (child.nodeType === 3) continue;                 // text — always fine
        if (child.nodeType !== 1) { child.remove(); continue; } // comments etc.
        const tag = child.tagName;
        if (DROP_TAGS.has(tag)) { child.remove(); continue; }
        walk(child);
        if (!KEEP_TAGS.has(tag)) {                          // unknown wrapper: keep the text, drop the tag
          child.replaceWith(...Array.from(child.childNodes));
          continue;
        }
        for (const attr of Array.from(child.attributes)) {  // strip styles, handlers, everything unlisted
          const name = attr.name.toLowerCase();
          const keep =
            (tag === "A" && name === "href" && SAFE_URL.test(attr.value.trim())) ||
            (tag === "UL" && name === "class" && attr.value === "checklist") ||
            (tag === "LI" && name === "class" && attr.value === "checked");
          if (!keep) child.removeAttribute(attr.name);
        }
        if (tag === "A") { child.setAttribute("target", "_blank"); child.setAttribute("rel", "noopener noreferrer"); }
      }
    };
    walk(doc.body);
    return doc.body.innerHTML;
  };

  // HTML -> plain text, for note previews and search. Deliberately avoids the
  // DOM: tags are stripped textually and entities decoded via a <textarea>,
  // whose contents the parser treats as text, so nothing can execute.
  const _decoder = document.createElement("textarea");
  App.htmlToText = function (html) {
    const stripped = String(html || "")
      .replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ")
      .replace(/<\/?(h[1-6]|div|p|li|ul|ol|blockquote|pre|tr|br)\b[^>]*>/gi, " ") // block edges become spaces
      .replace(/<[^>]*>/g, "");
    _decoder.innerHTML = stripped;
    return (_decoder.value || "").replace(/ /g, " ");
  };

  App.clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

  // User-supplied link -> a URL safe to put in href, or "" if it isn't one.
  // Only http/https: a "javascript:" or "data:" URL in a link the user pasted
  // would run as soon as they clicked it. A bare "oxford.ac.uk" is assumed https.
  App.safeURL = function (url) {
    const raw = String(url || "").trim();
    if (!raw) return "";
    const withScheme = /^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : "https://" + raw;
    try {
      const u = new URL(withScheme);
      return u.protocol === "http:" || u.protocol === "https:" ? u.href : "";
    } catch (e) { return ""; }
  };

  // "https://www.commonapp.org/apply" -> "commonapp.org" (for link labels)
  App.urlHost = function (url) {
    try { return new URL(App.safeURL(url)).hostname.replace(/^www\./, ""); }
    catch (e) { return ""; }
  };

  App.debounce = function (fn, ms) {
    let t;
    return function (...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); };
  };

  /* ---------- dates (all local-timezone, no UTC pitfalls) ---------- */
  const D = (App.dates = {});

  // Date -> "YYYY-MM-DD" in local time
  D.toStr = function (date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };

  // "YYYY-MM-DD" -> local Date at midnight (never UTC-parsed)
  D.parse = function (str) {
    if (!str) return null;
    const [y, m, d] = str.slice(0, 10).split("-").map(Number);
    if (!y || !m || !d) return null;
    return new Date(y, m - 1, d);
  };

  D.today = () => D.toStr(new Date());

  D.addDays = function (str, n) {
    const d = D.parse(str);
    d.setDate(d.getDate() + n);
    return D.toStr(d);
  };

  D.addMonths = function (str, n) {
    const d = D.parse(str);
    const day = d.getDate();
    d.setDate(1);
    d.setMonth(d.getMonth() + n);
    const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(day, last));
    return D.toStr(d);
  };

  D.diffDays = function (a, b) { // b - a in whole days
    return Math.round((D.parse(b) - D.parse(a)) / 86400000);
  };

  D.dayOfWeek = (str) => D.parse(str).getDay(); // 0=Sun..6=Sat

  D.mondayOf = function (str) {
    const d = D.parse(str);
    const dow = d.getDay();
    d.setDate(d.getDate() - ((dow + 6) % 7));
    return D.toStr(d);
  };

  const MONTHS_S = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const DOWS_L = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  D.fmtShort = function (str) { // "Mar 4"
    const d = D.parse(str);
    return d ? `${MONTHS_S[d.getMonth()]} ${d.getDate()}` : "";
  };
  D.fmtMed = function (str) { // "Mar 4, 2026"
    const d = D.parse(str);
    return d ? `${MONTHS_S[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}` : "";
  };
  D.fmtLong = function (str) { // "Wednesday, March 4"
    const d = D.parse(str);
    return d ? d.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }) : "";
  };
  D.fmtMonthYear = function (str) {
    const d = D.parse(str);
    return d ? d.toLocaleDateString(undefined, { month: "long", year: "numeric" }) : "";
  };

  // ISO datetime -> local "YYYY-MM-DD"
  D.isoToDateStr = function (iso) {
    if (!iso) return null;
    const d = new Date(iso);
    return isNaN(d) ? null : D.toStr(d);
  };
  // ISO datetime -> minutes from local midnight
  D.isoToMin = function (iso) {
    const d = new Date(iso);
    return isNaN(d) ? 0 : d.getHours() * 60 + d.getMinutes();
  };

  D.minToLabel = function (min) { // 570 -> "9:30 AM"
    const h = Math.floor(min / 60), m = min % 60;
    const h12 = h % 12 === 0 ? 12 : h % 12;
    const ap = h < 12 ? "AM" : "PM";
    return m === 0 ? `${h12} ${ap}` : `${h12}:${String(m).padStart(2, "0")} ${ap}`;
  };

  App.fmtMinutes = function (mins) {
    mins = Math.round(mins || 0);
    if (!mins) return "0m";
    const h = Math.floor(mins / 60), m = mins % 60;
    if (h === 0) return `${m}m`;
    if (m === 0) return `${h}h`;
    return `${h}h ${m}m`;
  };

  App.fmtClock = function (totalSec) {
    totalSec = Math.max(0, Math.floor(totalSec));
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };

  /* ---------- store ---------- */
  const STORAGE_KEY = "ib-study-tracker:v1";

  App.defaultSettings = function () {
    return {
      appName: "IB Tracker",
      hours_per_day: { monday: 4, tuesday: 4, wednesday: 4, thursday: 4, friday: 4, saturday: 2, sunday: 2 },
      work_start_hour: 8,
      work_end_hour: 22,
      ee_grade: "",
      tok_grade: "",
      theme: "auto",
      coach_tone: "warm",           // 'warm' | 'direct'
      ai_model: "anthropic/claude-3.7-sonnet",
      coach_ai_enabled: true,       // header toggle — AI mode used only when this AND a key are set
      ai_api_key: "",               // optional — OpenRouter key, enables AI coach; never exported in backups
      max_streak: 0,
      exam_date: "",                // IB exam session start date (YYYY-MM-DD) — powers the Dashboard countdown
      last_backup_at: "",           // ISO timestamp of the last exported backup (for the safety-net nudge)
      weekly_goal_hours: 10,        // target focused-study hours per week (0 = off)
      target_points: 40,            // IB points goal for the diploma projection
      pomodoro_enabled: false,      // Study Session pomodoro cycling
      pomodoro_focus_min: 25,
      pomodoro_break_min: 5,
      auto_update_check: true,      // look for a new version once a day (never installs on its own)
    };
  };

  // Seeded into state.portals on first load; editable and removable afterwards.
  // Defined here (not data.js) because migrate() runs while core.js loads.
  App.DEFAULT_PORTALS = [
    { label: "Common App", url: "https://www.commonapp.org/" },
    { label: "BridgeU", url: "https://app.bridge-u.com/" },
  ];

  App.emptyData = function () {
    return {
      version: 1,
      tasks: [], subtasks: [], subjects: [], grades: [], sessions: [],
      busyBlocks: [], templates: [], savedFilters: [], courses: [],
      gradeSnapshots: [],
      portals: [],        // [{ id, label, url }] — University quick-launch links
      scratchpad: "",     // legacy free-form quick notes (migrated into notes[])
      notes: [],          // [{ id, title, body, pinned, created_at, updated_at }]
      focus: App.defaultFocus(),
      settings: App.defaultSettings(),
      ui: { welcomed: false },
      timer: null,        // floating single-task timer state
      studySession: null, // study-session page state
      coach: { messages: [] },
    };
  }

  // Focus-mode state: an allowlist of sites/apps you permit yourself during a
  // locked session, plus the running "times I left" counter for the current lock.
  App.defaultFocus = function () {
    return {
      allowlist: [],      // [{ id, label }] — sites/apps you allow yourself
      locked: false,      // true while a lock-in session is active
      leaves: 0,          // times the app lost focus during this lock session
      lockedAt: "",       // ISO timestamp the current lock started
    };
  };;

  function migrate(data) {
    const base = App.emptyData();
    const out = Object.assign(base, data);
    out.settings = Object.assign(App.defaultSettings(), data.settings || {});
    out.ui = Object.assign({
      welcomed: false, backup_snooze_until: "", tour_done: false,
      update_last_check: "",        // ISO timestamp of the last version check
      update_dismissed_version: "", // banner hidden for this specific version
      portals_seeded: false,        // default University links added once
      license_key: "",              // the signed key as pasted; verified on boot
      license_date_seen: "",        // furthest date ever seen — defeats clock rollback
    }, data.ui || {});
    if (typeof out.scratchpad !== "string") out.scratchpad = "";
    out.focus = Object.assign(App.defaultFocus(), data.focus || {});
    if (!Array.isArray(out.focus.allowlist)) out.focus.allowlist = [];
    for (const k of ["tasks","subtasks","subjects","grades","sessions","busyBlocks","templates","savedFilters","courses","gradeSnapshots","notes","portals"]) {
      if (!Array.isArray(out[k])) out[k] = [];
    }
    // Seed the two common portals once. Guarded by a flag, not by emptiness, so
    // deleting them all doesn't resurrect them on the next load.
    if (!out.ui.portals_seeded) {
      out.ui.portals_seeded = true;
      if (!out.portals.length) {
        out.portals = App.DEFAULT_PORTALS.map((p) => ({ id: App.uid(), label: p.label, url: p.url }));
      }
    }
    // One-time lift: the old single scratchpad becomes the first proper note.
    if (!out.notes.length && out.scratchpad.trim()) {
      const now = new Date().toISOString();
      out.notes.push({ id: App.uid(), title: "Scratchpad", body: out.scratchpad, pinned: false, created_at: now, updated_at: now });
    }
    // the per-task Notes field was retired — drop any leftover task notes
    out.tasks.forEach((t) => { if (t && "notes" in t) delete t.notes; });
    if (!out.coach || !Array.isArray(out.coach.messages)) out.coach = { messages: [] };
    return out;
  }

  let state;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    state = raw ? migrate(JSON.parse(raw)) : App.emptyData();
  } catch (e) {
    console.error("Failed to load saved data:", e);
    state = App.emptyData();
  }

  let persistError = false;
  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      persistError = false;
    } catch (e) {
      if (!persistError && App.toast) App.toast("Couldn't save — storage is full", "error");
      persistError = true;
      console.error("Persist failed:", e);
    }
  }

  const listeners = new Set();
  App.state = () => state;
  App.subscribe = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };

  /* Read-only mode (an expired or missing licence) is enforced here, at the
     one place every change funnels through — 93 call sites reach state only
     via update(). Reading, searching, reports and Export backup all keep
     working: data is never held hostage, you just can't add to it.

     {system: true} is the exception, for writes that must survive read-only —
     entering a licence key, dismissing a banner, the updater's bookkeeping.
     It marks plumbing, never a user edit. */
  let blockedToastAt = 0;
  function blockedByLicense(opts) {
    if (opts && opts.system) return false;
    if (!App.license || !App.license.readOnly || !App.license.readOnly()) return false;
    const now = Date.now();
    if (now - blockedToastAt > 4000) {          // one nudge, not one per keystroke
      blockedToastAt = now;
      if (App.toast) App.toast("Read-only — add a licence key in Settings to make changes", "error");
    }
    return true;
  }
  // Silent query for the UI (disabling buttons); doesn't nudge.
  App.writeBlocked = () => !!(App.license && App.license.readOnly && App.license.readOnly());

  // update(fn, {silent, system}) — fn mutates state; then persist; then re-render unless silent
  App.update = function (fn, opts) {
    if (blockedByLicense(opts)) return false;
    fn(state);
    persist();
    if (!opts || !opts.silent) listeners.forEach((l) => { try { l(); } catch (e) { console.error(e); } });
    return true;
  };

  App.replaceState = function (newData, opts) {
    if (blockedByLicense(opts)) return false;
    state = migrate(newData);
    persist();
    listeners.forEach((l) => { try { l(); } catch (e) { console.error(e); } });
    return true;
  };

  App.STORAGE_KEY = STORAGE_KEY;

  /* ---------- router (hash-based) ---------- */
  App.pages = {}; // name -> { title, render(container), mount?(container) }

  App.currentPage = function () {
    const h = (location.hash || "#/dashboard").replace(/^#\//, "");
    return h.split("?")[0] || "dashboard";
  };

  App.navigate = function (name) {
    if (App.currentPage() === name) { App.render(); return; }
    location.hash = "#/" + name;
  };

  /* ---------- render loop ---------- */
  // Coalesce bursts of updates into one render per microtask.
  // (Not requestAnimationFrame — it never fires in hidden tabs, which would
  // silently stall the UI.)
  let renderScheduled = false;
  App.render = function () {
    if (renderScheduled) return;
    renderScheduled = true;
    queueMicrotask(() => {
      renderScheduled = false;
      App.renderNow();
    });
  };

  App.renderNow = function () {
    const name = App.currentPage();
    const page = App.pages[name] || App.pages.dashboard;
    const main = document.getElementById("main");
    if (!page || !main) return;
    App.ui && App.ui.closePopovers && App.ui.closePopovers();
    const appEl = document.getElementById("app");
    if (appEl) appEl.classList.toggle("focus-active", name === "focus");
    // run a page's onEnter once, when navigating INTO it (not on same-page re-renders)
    if (App._lastPage !== name) {
      App._lastPage = name;
      if (page.onEnter) { try { page.onEnter(); } catch (e) { console.error(e); } }
    }
    main.innerHTML = page.render();
    if (page.mount) page.mount(main);
    App.renderChrome();
    document.title = `${page.title} · ${state.settings.appName || "IB Tracker"}`;
  };

  App.renderChrome = function () {
    if (App.renderSidebar) App.renderSidebar();
    if (App.timerUI && App.timerUI.renderFloating) App.timerUI.renderFloating();
    if (App.coachUI && App.coachUI.renderBubble) App.coachUI.renderBubble();
  };

  /* ---------- theme ---------- */
  App.applyTheme = function () {
    const pref = state.settings.theme || "auto";
    const dark = pref === "dark" || (pref === "auto" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  };
  window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => App.applyTheme());
})();
