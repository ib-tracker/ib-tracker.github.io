/* license.js — licence keys.
   ---------------------------------------------------------------------------
   Keys are prepaid blocks of access: 1, 3, 6 or 12 months, or lifetime. Nothing
   auto-renews. A key looks like

     IBT1.<payload>.<signature>          both parts base64url

   where payload is compact JSON {n,t,x,id} and the signature is ECDSA P-256 /
   SHA-256 over the payload STRING exactly as it appears in the key — signing
   the encoded text rather than the JSON sidesteps every canonicalisation
   question about key order and whitespace.

   Only the PUBLIC key ships. The app can therefore check a key but not mint
   one, so nobody generates their own by reading this file. Someone determined
   can still patch the app — that is inherent to software that runs on a
   machine you don't control, and the point here is to make honesty easy, not
   to make dishonesty impossible.

   ECDSA P-256, not Ed25519: Electron 33 ships Chromium 130, whose WebCrypto
   does NOT implement Ed25519. Verified on the real target, where it throws
   NotSupportedError. P-256 works everywhere the app runs.                    */
(function () {
  "use strict";
  const App = window.App;
  const L = (App.license = {});

  // Public half of the signing keypair. Safe to publish — see above.
  const PUBLIC_SPKI_B64 =
    "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE+Uejkim34yaGl8E0/zPXKmzxLE9mlMYuDmU5ktBbhbSdcb11u9liqHIcFTMmbCGPe629LbZwZMePdSG/p+JI8w==";

  const TIERS = {
    "1m":   { label: "1 month",   months: 1 },
    "3m":   { label: "3 months",  months: 3 },
    "6m":   { label: "6 months",  months: 6 },
    "12m":  { label: "12 months", months: 12 },
    "life": { label: "Lifetime",  months: 0 },
  };
  L.TIERS = TIERS;

  /* ---------- state ---------- */
  // "none" (never entered) | "licensed" | "expired" | "invalid"
  L.status = "none";
  L.tier = "";
  L.name = "";
  L.expiry = "";      // "" for lifetime
  L.id = "";
  L.reason = "";      // why an entered key isn't being honoured
  L.ready = false;    // verification has finished at least once

  L.isLifetime = () => L.status === "licensed" && !L.expiry;
  L.tierLabel = () => (TIERS[L.tier] ? TIERS[L.tier].label : L.tier || "");
  // The whole point of the licence: everything is readable, editing is not.
  // Fails CLOSED: before the first check has finished we don't yet know whether
  // this copy is licensed, and guessing "yes" would let anything that writes
  // during boot slip past the one gate every change funnels through.
  L.readOnly = () => !L.ready || L.status !== "licensed";

  /* ---------- encoding helpers ---------- */
  function b64urlToBytes(s) {
    s = String(s).replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4) s += "=";
    const bin = atob(s);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function b64ToBytes(s) {
    const bin = atob(s);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  let pubKeyPromise = null;
  function publicKey() {
    if (!pubKeyPromise) {
      pubKeyPromise = crypto.subtle.importKey(
        "spki", b64ToBytes(PUBLIC_SPKI_B64),
        { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    }
    return pubKeyPromise;
  }

  /* ---------- the clock ----------
     A licence that expires is only as honest as the machine's clock, and
     winding it back is the obvious way to cheat. So remember the furthest date
     ever seen and judge expiry against max(now, furthest): moving the clock
     back can never buy time, while a genuine correction of a few hours or a
     timezone change costs nobody anything. */
  function effectiveToday() {
    const s = App.state();
    const now = App.dates.today();
    const seen = (s.ui && s.ui.license_date_seen) || "";
    const eff = seen && seen > now ? seen : now;
    if (eff !== seen) {
      App.update((st) => { st.ui.license_date_seen = eff; }, { silent: true, system: true });
    }
    return eff;
  }
  L.effectiveToday = effectiveToday;

  /* ---------- verification ---------- */
  // Resolves to a plain result; never throws, so a malformed key can't wedge boot.
  L.verify = async function (key) {
    const raw = String(key || "").trim().replace(/\s+/g, "");
    if (!raw) return { ok: false, reason: "" };

    const parts = raw.split(".");
    if (parts.length !== 3 || parts[0] !== "IBT1") {
      return { ok: false, reason: "That doesn't look like a licence key." };
    }
    const [, payloadB64, sigB64] = parts;

    let sigOK = false;
    try {
      sigOK = await crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        await publicKey(),
        b64urlToBytes(sigB64),
        new TextEncoder().encode(payloadB64));
    } catch (e) {
      return { ok: false, reason: "That key is damaged — check it copied in full." };
    }
    if (!sigOK) return { ok: false, reason: "That key isn't valid." };

    let p;
    try { p = JSON.parse(new TextDecoder().decode(b64urlToBytes(payloadB64))); }
    catch (e) { return { ok: false, reason: "That key is damaged — check it copied in full." }; }

    const tier = String(p.t || "");
    if (!TIERS[tier]) return { ok: false, reason: "That key is for a plan this version doesn't know about." };

    const expiry = tier === "life" ? "" : String(p.x || "");
    if (tier !== "life" && !/^\d{4}-\d{2}-\d{2}$/.test(expiry)) {
      return { ok: false, reason: "That key is damaged — check it copied in full." };
    }

    return {
      ok: true,
      tier,
      expiry,
      name: String(p.n || ""),
      id: String(p.id || ""),
      expired: !!expiry && expiry < effectiveToday(),
    };
  };

  /* ---------- apply / load ---------- */
  function settle(res) {
    if (!res || !res.ok) {
      L.status = res && res.reason ? "invalid" : "none";
      L.tier = L.name = L.expiry = L.id = "";
      L.reason = (res && res.reason) || "";
    } else {
      L.status = res.expired ? "expired" : "licensed";
      L.tier = res.tier; L.name = res.name; L.expiry = res.expiry; L.id = res.id;
      L.reason = res.expired ? "This licence ran out on " + App.dates.fmtShort(res.expiry) + "." : "";
    }
    L.ready = true;
    return L.status;
  }

  L.storedKey = () => (App.state().ui && App.state().ui.license_key) || "";

  // Called once during boot, before the first render, so the app never briefly
  // allows edits it is about to refuse.
  L.load = async function () {
    return settle(await L.verify(L.storedKey()));
  };

  // Save only if it actually verifies — refuse to store a key we'd reject
  // later, so Settings can never show a key that silently does nothing.
  L.apply = async function (key) {
    const res = await L.verify(key);
    if (!res.ok) { settle(res); return res; }
    App.update((s) => { s.ui.license_key = String(key).trim().replace(/\s+/g, ""); },
      { silent: true, system: true });
    settle(res);
    return res;
  };

  L.remove = function () {
    App.update((s) => { s.ui.license_key = ""; }, { silent: true, system: true });
    settle({ ok: false, reason: "" });
  };

  L.daysLeft = function () {
    if (!L.expiry) return Infinity;
    return App.dates.diffDays(effectiveToday(), L.expiry);
  };

  /* ---------- banner ---------- */
  // Not dismissible: unlike an update notice, this explains why the app isn't
  // accepting changes. Hiding it would just leave edits silently failing.
  L.bannerHTML = function () {
    if (!L.readOnly()) return "";
    const esc = App.esc;
    const headline = L.status === "expired"
      ? esc(L.reason)
      : L.status === "invalid"
        ? esc(L.reason)
        : "This copy doesn't have a licence key yet.";
    return `
      <div class="license-banner">
        ${App.icon("alertTri")}
        <div class="lb-text">
          <strong>Read-only.</strong> ${headline}
          Everything is still here to read, search and export — you just can't
          add or change anything until a key is in.
        </div>
        <button class="btn btn-primary btn-sm" data-license-goto>Add a key</button>
      </div>`;
  };

  L.mountBanner = function (el) {
    const b = el.querySelector("[data-license-goto]");
    if (b) b.addEventListener("click", () => App.navigate("settings"));
  };
})();
