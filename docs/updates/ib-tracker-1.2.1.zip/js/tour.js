/* tour.js — first-run guided spotlight tour.
   Dims the screen, cuts a spotlight over a real element and explains it.
   Steps live on the Dashboard + sidebar (always present), so nothing navigates
   mid-tour and the highlighted nodes stay put. */
(function () {
  "use strict";
  const App = window.App;
  const esc = App.esc;
  const Tour = (App.tour = {});

  const STEPS = [
    { sel: ".sidebar-search", title: "Find anything, fast",
      body: "Press ⌘K (or Ctrl-K) from anywhere to jump to a task or page — or just type a task like “Essay due friday 2h high” and it’s added instantly." },
    { sel: '[data-nav][href="#/dashboard"]', title: "Dashboard — your home base", placement: "right",
      body: "Every visit starts here: overdue and upcoming tasks, your exam countdown, weekly goal, XP and overall progress at a glance." },
    { sel: '[data-nav][href="#/timeline"]', title: "Timeline — every open task", placement: "right",
      body: "All your open tasks in one list, sorted by due date. Filter by subject or priority, save custom views, and select several to reschedule or complete in bulk." },
    { sel: '[data-nav][href="#/calendar"]', title: "Calendar — the month view", placement: "right",
      body: "See due dates across the month, colour-coded by subject, with a heat-map of the study time you’ve logged each day." },
    { sel: '[data-nav][href="#/study"]', title: "Study Session — the focus timer", placement: "right",
      body: "Queue up tasks and run a timer (with an optional Pomodoro cycle). Every session is logged, powering your streak, XP and analytics." },
    { sel: '[data-nav][href="#/focus"]', title: "Focus — just work", placement: "right",
      body: "A calm, full-screen “get in the zone” view: today’s top priority and one big timer, with everything else stripped away." },
    { sel: '[data-nav][href="#/scheduler"]', title: "Scheduler — plan your week", placement: "right",
      body: "Drag tasks onto a weekly calendar, block out classes and busy time, then hit Auto-Schedule to arrange everything around your free hours in one click." },
    { sel: '[data-nav][href="#/analytics"]', title: "Analytics — see your habits", placement: "right",
      body: "Charts for study time, subject balance, completions and how accurate your time estimates are — plus a printable progress report you can save as a PDF." },
    { sel: '[data-nav][href="#/coach"]', title: "Coach — advice on tap", placement: "right",
      body: "Chat for guidance grounded in your real tasks and grades, or ask it to make changes for you — reschedule, reprioritise, add tasks. You always confirm first." },
    { sel: '[data-nav][href="#/subjects"]', title: "Subjects — grouped by course", placement: "right",
      body: "The same tasks, grouped by subject, so you can zero in on one course at a time." },
    { sel: '[data-nav][href="#/core"]', title: "Core Requirements", placement: "right",
      body: "Track your TOK, Extended Essay and CAS work and watch each one’s progress climb toward done." },
    { sel: '[data-nav][href="#/grades"]', title: "Grades — your predicted score", placement: "right",
      body: "Record current and target grades per subject and set your TOK/EE grades — it works out your predicted IB total and where the biggest point gains are." },
    { sel: '[data-nav][href="#/university"]', title: "University — applications", placement: "right",
      body: "Track courses, offer conditions, deadlines, required documents and admissions tasks, with a live check of whether your grades meet each offer." },
    { sel: '[data-nav][href="#/templates"]', title: "Templates — reusable tasks", placement: "right",
      body: "Save routines you repeat — like a past-paper session with its sub-tasks — and spin up a ready-made task from one in a click." },
    { sel: '[data-nav][href="#/notes"]', title: "Notes — a quick scratchpad", placement: "right",
      body: "A free-form space for reminders, formulae or anything that isn’t a task. It saves as you type." },
    { sel: ".xp-card", title: "Earn XP as you go", placement: "left",
      body: "Completing tasks and logging focus time earns XP, levels, ranks and streaks. Hover the “?” on this card any time for the full rulebook." },
    { sel: '.sidebar-foot [data-action="new-task"]', title: "Add a task anytime", placement: "right",
      body: "This button is always here — assignments, IAs, revision, anything with a deadline. Extra options like recurrence and dependencies are one click away inside the form." },
    { sel: '[data-nav][href="#/settings"]', title: "Last stop: make it yours", placement: "right", navTo: "settings",
      body: "Head into Settings to add your six IB subjects, set your study hours and exam date, pick a theme, and back up your data. Let’s go there now — click Done." },
  ];

  let idx = 0, overlay = null, onResize = null;

  function el() { return overlay; }

  function cleanup() {
    if (onResize) { window.removeEventListener("resize", onResize); onResize = null; }
    if (overlay) { overlay.remove(); overlay = null; }
  }

  function finish() {
    cleanup();
    // system: the tour runs on first launch, for people who have no licence yet.
    // Without this the completion is refused and the tour replays every launch,
    // forever. UI bookkeeping, not a user edit.
    App.update((s) => { s.ui.tour_done = true; }, { silent: true, system: true });
  }

  function ensureOverlay() {
    if (overlay) return;
    overlay = document.createElement("div");
    overlay.className = "tour-overlay";
    overlay.innerHTML = `<div class="tour-spot"></div><div class="tour-card"></div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) { /* keep modal */ } });
  }

  function showStep() {
    ensureOverlay();
    const step = STEPS[idx];
    const spot = overlay.querySelector(".tour-spot");
    const card = overlay.querySelector(".tour-card");
    const target = step.center ? null : document.querySelector(step.sel);

    // skip a step whose target isn't on screen
    if (!step.center && !target) { next(); return; }

    const controls = `
      <div class="tour-actions">
        <button class="btn btn-ghost btn-sm" data-tour-skip>Skip</button>
        <div class="row" style="gap:8px">
          ${idx > 0 ? `<button class="btn btn-outline btn-sm" data-tour-back>Back</button>` : ""}
          <button class="btn btn-primary btn-sm" data-tour-next>${idx === STEPS.length - 1 ? "Done" : "Next"}</button>
        </div>
      </div>`;
    card.innerHTML = `
      <div class="tour-step-count">${idx + 1} / ${STEPS.length}</div>
      <div class="tour-title">${esc(step.title)}</div>
      <div class="tour-body">${esc(step.body)}</div>
      ${controls}`;

    if (step.center || !target) {
      spot.style.display = "none";
      card.classList.add("center");
      card.style.top = ""; card.style.left = ""; card.style.right = ""; card.style.bottom = "";
    } else {
      target.scrollIntoView({ block: "center", behavior: "instant" in window ? "instant" : "auto" });
      const r = target.getBoundingClientRect();
      const pad = 6;
      spot.style.display = "block";
      spot.style.top = (r.top - pad) + "px";
      spot.style.left = (r.left - pad) + "px";
      spot.style.width = (r.width + pad * 2) + "px";
      spot.style.height = (r.height + pad * 2) + "px";
      card.classList.remove("center");
      positionCard(card, r, step.placement || "bottom");
    }

    card.querySelector("[data-tour-next]").addEventListener("click", next);
    card.querySelector("[data-tour-skip]").addEventListener("click", finish);
    const back = card.querySelector("[data-tour-back]");
    if (back) back.addEventListener("click", prev);
  }

  function positionCard(card, r, placement) {
    const CW = 300, gap = 12, vw = window.innerWidth, vh = window.innerHeight;
    card.style.width = CW + "px";
    // measure height after content set
    const ch = card.offsetHeight || 150;
    let top, left;
    if (placement === "right" && r.right + gap + CW < vw) {
      left = r.right + gap; top = r.top;
    } else if (placement === "left" && r.left - gap - CW > 0) {
      left = r.left - gap - CW; top = r.top;
    } else if (r.bottom + gap + ch < vh) {
      top = r.bottom + gap; left = r.left;
    } else {
      top = r.top - gap - ch; left = r.left;
    }
    left = Math.max(12, Math.min(left, vw - CW - 12));
    top = Math.max(12, Math.min(top, vh - ch - 12));
    card.style.top = top + "px";
    card.style.left = left + "px";
    card.style.right = "auto"; card.style.bottom = "auto";
  }

  function next() {
    if (idx >= STEPS.length - 1) {
      const dest = STEPS[idx] && STEPS[idx].navTo;
      finish();
      if (dest) App.navigate(dest); // drop them straight into Settings to fill things in
      return;
    }
    idx++;
    showStep();
  }
  function prev() { if (idx > 0) { idx--; showStep(); } }

  Tour.start = function () {
    idx = 0;
    cleanup();
    // land on the Dashboard (where the highlighted widgets live), then run
    if (App.currentPage() !== "dashboard") App.navigate("dashboard");
    if (window.innerWidth <= 860 && App.ui.openSidebar) App.ui.openSidebar();
    onResize = () => showStep();
    window.addEventListener("resize", onResize);
    setTimeout(showStep, 90);
  };

  Tour.maybeAutoStart = function () {
    const s = App.state();
    if (!s.ui.tour_done && s.ui.welcomed) {
      // only auto-run once the user is past the first-run welcome card
      setTimeout(() => { if (!App.state().ui.tour_done) Tour.start(); }, 400);
    }
  };
})();
